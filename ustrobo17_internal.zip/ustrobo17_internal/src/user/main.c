#include "main.h"

u32 ticks = 0;

int main(){
  //initialization
  ticks_init();
  ticks_reset();

  while(1)
	{
    if(ticks != get_ticks())
		{
      ticks = get_ticks();

      if(ticks%20 == 0)
			{
				//...
      }
    }
  }
}
