//including header files
#include "main.h"

int main()
{
	//initialization
	ticks_init();
	tft_init(0,BLUE, WHITE, RED);
	
	//variables
	uint32_t ticks = 0;
	
  //an infinite loop
	while(1)
	{
    //regulating time interval to every 1 ms
    if(get_ticks() != ticks)
		{
			//updating the value stored in ticks
      ticks = get_ticks();
			
			//task 1 - execute every 100 ms
      if(ticks % 100 == 5)
      {
				//...
      }
			
			//task 2 - execute every 50 ms
			if(ticks % 50 == 3)
      {
				//...
      }
      
			//task 3 - execute every 10 ms
			if(ticks % 10 == 7)
      {
				//...
      }
			
		}
	}
}
