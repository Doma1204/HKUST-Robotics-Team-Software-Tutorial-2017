//including header files
#include "main.h"

int main()
{
	//initialization
	ticks_init();
	tft_init(0,BLUE, WHITE, RED);
	
	//variables
	uint32_t ticks = 0;
	
  //an infinite loop
	while(1)
	{
    //regulating time interval
    if(get_ticks() != ticks)
		{
			//updating the value stored in ticks
      ticks=get_ticks();
			
			//print ticks on tft every 1000ms
			if(ticks % 100 == 0)
			{
				tft_clear_line(1);
				tft_prints(1,1,"%d",ticks/100%10);
				tft_update();
			}
			
      //some other tasks
      if(ticks % 100 == 5)
      {
        //...
      }
      
      if(ticks % 100 == 11)
      {
        //...
      }
      
      if(ticks % 25 == 19)
      {
        //...
      }
      
		}
	}
}
