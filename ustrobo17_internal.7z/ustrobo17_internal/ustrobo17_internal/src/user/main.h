#ifndef __MAIN_H
#define __MAIN_H

#include "stm32f10x.h"
#include "ticks.h"
#include "leds.h"
#include "uart.h"
//#include "buzzer.h"
//#include "buzzer_song.h"

#include "servo.h"
#include "motor.h"
#include "tft.h"
#include "gpio.h"
#include "pneumatic.h"

int main(void);

#endif	/* __MAIN_H */
